function getTriangle(base = 1, height = 1) {
  return base * height / 2;
}

console.log(getTriangle(5));
//console.log(getTriangle(5, null));
//console.log(getTriangle(5, undefined));

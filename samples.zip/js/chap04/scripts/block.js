(function() {
  var i = 5;
  console.log(i);
}).call(this);

console.log(i);

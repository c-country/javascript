var getTriangle = function(base, height) {
  return base * height / 2;
};

console.log(getTriangle(5, 2));
getTriangle = 0;
console.log(getTriangle);

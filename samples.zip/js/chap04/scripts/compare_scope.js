if (true) {
  var i = 5;
}

console.log(i);

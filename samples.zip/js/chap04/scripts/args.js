function showMessage(value) {
  console.log(value);
}

showMessage();
showMessage('山田');
showMessage('山田', '鈴木');

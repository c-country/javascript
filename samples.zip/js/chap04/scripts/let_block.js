{
  let i = 5;
  console.log(i);
}

console.log(i);

'use strict';

function show(_ref) {
  var name = _ref.name;

  console.log(name);
};

var member = {
  mid: 'Y0001',
  name: '山田太郎',
  address: 't_yamada@example.com'
};

show(member);

"use strict";

console.log(Math.max.apply(Math, [15, -3, 78, 1]));

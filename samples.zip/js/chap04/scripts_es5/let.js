"use strict";

if (true) {
  var _i = 5;
}

console.log(i);

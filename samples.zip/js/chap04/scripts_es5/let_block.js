"use strict";

{
  var _i = 5;
  console.log(_i);
}

console.log(i);

"use strict";

var getTriangle = function getTriangle(base, height) {
  return base * height / 2;
};
console.log(getTriangle(5, 2));

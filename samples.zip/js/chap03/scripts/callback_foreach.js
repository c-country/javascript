var data = [2, 3, 4, 5];
data.forEach(function(value, index, array) {
  console.log(value * value);
});

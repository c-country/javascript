var p = /[\/\.\-]/gi;
console.log('2016/12/04'.split(p));
console.log('2016-12-04'.split(p));
console.log('2016.12.04'.split(p));

var str = 'console.log("eval関数")';
eval(str);

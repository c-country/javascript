var str = 'こんにちは！';
// var str = new String('こんにちは！');
console.log(str.length);

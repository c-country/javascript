console.log(isNaN('hoge'));
console.log(Number.isNaN('hoge'));

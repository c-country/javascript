let str = '𠮟ります';
console.log(str.match(/^.ります$/gu));
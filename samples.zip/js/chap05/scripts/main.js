import { Member, Area } from './lib/Util';

var m = new Member('太郎', '山田');
console.log(m.getName());

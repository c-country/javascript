let name = '山田太郎';
let birth = new Date(1970, 5, 25);
let member = { name, birth };

console.log(member);

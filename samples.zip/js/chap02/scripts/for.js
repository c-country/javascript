for (var x = 8; x < 10; x++) {
  console.log('xの値は' + x);
}

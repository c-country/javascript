console.log(10 + 1);
console.log('10'+ 1);
var today = new Date();
console.log(1234 + today);

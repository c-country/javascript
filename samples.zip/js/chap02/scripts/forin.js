var data = { apple:150, orange:100, banana: 120 };
for (var key in data) {
  console.log(key + '=' + data[key]);
}

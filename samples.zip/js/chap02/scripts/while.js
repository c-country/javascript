var x = 8;
while(x < 10) {
  console.log('xの値は' + x);
  x++;
}

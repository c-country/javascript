var data = ['JavaScript', ['jQuery', 'prototype.js'], 'ASP.NET'];
console.log(data[1][0]);

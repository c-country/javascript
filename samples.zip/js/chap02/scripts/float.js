console.log(0.2 * 3);
console.log(0.2 * 3 === 0.6);

console.log(((0.2 * 10) * 3) / 10);
console.log((0.2 * 10) * 3 === 0.6 * 10);
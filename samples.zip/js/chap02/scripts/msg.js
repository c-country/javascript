msg = 'こんにちは、JavaScript！';
console.log(msg);
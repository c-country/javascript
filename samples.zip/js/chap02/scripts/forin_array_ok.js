var data = [ 'apple', 'orange', 'banana' ];
for (var i = 0, len = data.length; i < len; i++) {
//for (var i = 0; i < data.length; i++) {
  console.log(data[i]);
}

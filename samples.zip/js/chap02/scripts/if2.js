var x = 15;
if (x >= 10) {
  console.log('変数xは10以上です。');
}

let msg;

let x, y;

let greeting = 'こんにちは、世界！';

console.log(greeting);
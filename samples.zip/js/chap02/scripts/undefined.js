var x;
var obj = { a:12345 };
console.log(x);
console.log(obj.b);

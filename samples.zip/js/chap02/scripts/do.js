var x = 8;
do {
  console.log('xの値は' + x);
  x++;
} while(x < 10);

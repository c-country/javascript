var x = 80;
console.log((x >= 70) ? '合格' : '不合格');

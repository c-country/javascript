var data = ['JavaScript', 'Ajax', 'ASP.NET'];
console.log(data[0]);

"use strict";

var x = 1;
var y = 2;
var _ref = [y, x];
x = _ref[0];
y = _ref[1];


console.log(x, y);

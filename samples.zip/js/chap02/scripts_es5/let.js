'use strict';

var msg = void 0;

var x = void 0,
    y = void 0;

var greeting = 'こんにちは、世界！';

console.log(greeting);

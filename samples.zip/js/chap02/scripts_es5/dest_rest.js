"use strict";

var data = [56, 40, 26, 82, 19, 17, 73, 99];
var x0 = data[0];
var x1 = data[1];
var x2 = data[2];
var other = data.slice(3);


console.log(x0);
console.log(x1);
console.log(x2);
console.log(other);

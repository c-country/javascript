'use strict';

var book = { title: 'Javaポケットリファレンス ', publish: '技術評論社' };
var name = book.title;
var company = book.publish;


console.log(name);
console.log(company);
